<?php
/**
 * @var PDO $pdo
 * @var string $actionName
 */
require "model/person.php";
require "model/users.php";
require "model/user.php";

    $errors = [];
    $action = 'create';
    $unlinkedUsers = getUnlinkedUsers($pdo);


    if (!empty($_GET['id'])) {
        $action = 'edit';
        $person = getPerson($pdo, $_GET['id']);
        if(!is_array($person)) {
            $errors = $person;
        }
    }

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest'
    ) {
        switch ($actionName) {
            case 'create':
                $lastName = !empty($_POST['last_name']) ? cleanString($_POST['last_name']) : null;
                $firstName = !empty($_POST['first_name']) ? cleanString($_POST['first_name']) : null;
                $address = !empty($_POST['address']) ? cleanString($_POST['address']) : null;
                $zipCode = !empty($_POST['zip_code']) ? cleanString($_POST['zip_code']) : null;
                $city = !empty($_POST['city']) ? cleanString($_POST['city']) : null;
                $phone = !empty($_POST['phone']) ? cleanString($_POST['phone']) : null;
                $type = !empty($_POST['type']) ? cleanString($_POST['type']) : null;
                $linkedUserId = !empty($_POST['linked_user_id']) ? cleanString($_POST['linked_user_id']) : null;

                if (empty($lastName) || empty($firstName) || empty($address) || empty($phone) || empty($city) || empty($type)) {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => 'Veuillez renseigner tous les champs']);
                    exit();
                }

                $fileName = null;

                if (!empty($_FILES["image"]["name"])) {
                    $tmpName = $_FILES["image"]['tmp_name'];
                    $fileName = $_FILES["image"]["name"];
                    $ext = pathinfo($fileName, PATHINFO_EXTENSION);
                    $uniqFilename = uniqid();
                    $finalName = $uniqFilename . "." . $ext;

                    move_uploaded_file($tmpName,$_SERVER["DOCUMENT_ROOT"] . UPLOAD_DIRECTORY . $finalName);
                }

                //je crée la personne et je récupère son id
                $res = createPerson($pdo, $lastName, $firstName, $address, $zipCode, $city, $phone, $type, $finalName);

                if (is_string($res)){
                    header("Content-Type: application/json");
                    echo json_encode(['error' => $res]);
                    exit();
                }

                // je vérifier si linkedUserId n'est pas déjà lié à une personne
                $isLinked = isLinkedUser($pdo, $linkedUserId);
                if ($isLinked) {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => 'Cet utilisateur est déjà lié à une personne']);
                    exit();
                }


                // je créer la liaison entre personne et user grace aux id
                $link = linkUserToPerson($pdo, $linkedUserId, $res);

                if (is_bool($link)) {
                    header("Content-Type: application/json");
                    echo json_encode(['success' => true]);
                    exit();
                }  else {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => $res]);
                    exit();
                }

            break;
            case 'update':
                $personId = !empty($_GET['id']) ? cleanString($_GET['id']) : null;
                $lastName = !empty($_POST['last_name']) ? cleanString($_POST['last_name']) : null;
                $firstName = !empty($_POST['first_name']) ? cleanString($_POST['first_name']) : null;
                $address = !empty($_POST['address']) ? cleanString($_POST['address']) : null;
                $zipCode = !empty($_POST['zip_code']) ? cleanString($_POST['zip_code']) : null;
                $city = !empty($_POST['city']) ? cleanString($_POST['city']) : null;
                $phone = !empty($_POST['phone']) ? cleanString($_POST['phone']) : null;
                $type = !empty($_POST['type']) ? cleanString($_POST['type']) : null;
                $linkedUserId = !empty($_POST['linked_user_id']) ? cleanString($_POST['linked_user_id']) : null;

                if (empty($personId) || empty($lastName) || empty($firstName) || empty($address) || empty($phone) || empty($city) || empty($type)) {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => 'Veuillez renseigner tous les champs']);
                    exit();
                }

                $res = updatePerson($pdo,$personId, $lastName, $firstName, $address, $zipCode, $city, $phone, $type);

                if (is_string($res)) {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => $res]);
                    exit();
                }

                if ($linkedUserId !== null) {
                    // je vérifier si linkedUserId n'est pas déjà lié à une personne
                    $isLinked = isLinkedUser($pdo, $linkedUserId);
                    if ($isLinked) {
                        header("Content-Type: application/json");
                        echo json_encode(['error' => 'Cet utilisateur est déjà lié à une personne']);
                        exit();
                    }

                    // je créer la liaison entre personne et user grace aux id
                    $link = linkUserToPerson($pdo, $linkedUserId, $personId);

                    if (is_bool($link)) {
                        header("Content-Type: application/json");
                        echo json_encode(['success' => true]);
                        exit();
                    } else {
                        header("Content-Type: application/json");
                        echo json_encode(['error' => $link]);
                        exit();
                    }
                }

                if (is_bool($res)) {
                    header("Content-Type: application/json");
                    echo json_encode(['success' => true]);
                    exit();
                }

                break;
            case 'delete_image':
                $id = !empty($_GET['id']) ? (int)cleanString($_GET['id']) : null;
                if (null === $id || !is_int($id)) {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => "id incorrect"]);
                    exit();
                }

                $person = getPerson($pdo, $id);
                if (is_string($person) || empty($person)) {
                    header("Content-Type: application/json");
                    echo json_encode(['error' => "Impossible de sélectionner la personne"]);
                    exit();
                }

                if (file_exists($_SERVER["DOCUMENT_ROOT"] . UPLOAD_DIRECTORY . $person['image'])) {
                    try {
                        unlink($_SERVER["DOCUMENT_ROOT"] . UPLOAD_DIRECTORY . $person['image']);
                    } catch (Exception $e) {
                        header("Content-Type: application/json");
                        echo json_encode(['error' => "Impossible de détruire le fichier ". $e->getMessage()]);
                        exit();
                    }
                    $reset = resetImage($pdo, $id);

                    if (is_string($reset)) {
                        header("Content-Type: application/json");
                        echo json_encode(['error' => $reset]);
                        exit();
                    } else {
                        header("Content-Type: application/json");
                        echo json_encode(['success' => true]);
                        exit();
                    }
                }
            break;
        }
    }
require "view/person.php";