<?php
/**
 * @var array $persons
 */
require("_partials/errors.php")
?>
<div class="row">
    <div class="col">
        <div class="h1 pt-2 pb-2 text-center">
            Liste des Personnes
        </div>
        <div class="row">
            <div class="col d-flex justify-content-center">
                <div class="spinner-border text-primary d-none" role="status" id="spinner">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="mb-3 d-flex justify-content-end">
                <a href="index.php?component=person" type="button" class="btn btn-primary" ><i class="fa fa-plus me-2"></i>Ajouter</a>
            </div>
        </div>
        <table class="table" id="list-persons">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nom</th>
                <th scope="col">Prénom</th>
                <th scope="col">Type</th>
                <th scope="col">Actions</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    </div>
</div>
<div class="row">
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center" id="pagination">

        </ul>
    </nav>
</div>
<script src="./assets/js/services/person.js" type="module"></script>
<script src="./assets/js/components/person.js" type="module"></script>
<script type="module">
    import {refreshList} from "./assets/js/components/person.js";

    document.addEventListener('DOMContentLoaded', async () => {
        const previousLink = document.querySelector('#previous-link')
        const nextLink = document.querySelector('#next-link')
        let currentPage = 1

        refreshList(currentPage)

        previousLink.addEventListener('click', async () => {
            if (currentPage > 1) {
                currentPage--
                await refreshList(currentPage)
            }
        })

        nextLink.addEventListener('click', async () => {
            currentPage++
            await refreshList(currentPage)

        })

    })
</script>