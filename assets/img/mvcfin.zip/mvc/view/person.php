<?php
/**
 * @var string $action
 * @var array $unlinkedUsers
 */
?>
<div class="row">
    <div class="col">
        <div class="h1 pt-2 pb-2 text-center">Créer / Modifier une personne</div>
        <form method="post" id="person-form" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="first_name" class="form-label">Prénom</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php  echo $person['first_name'] ?? ''; ?>" required>
            </div>
            <div class="mb-3">
                <label for="last_name" class="form-label">Nom</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php  echo $person['last_name'] ?? ''; ?>" >
            </div>
            <div class="mb-3">
                <label for="">Image</label>
                <input type="file" name="image" id="image" class="form-control"/>
            </div>
            <div class="mb-3 d-flex align-items-end" id="person-image">
                <?php  if (!empty($person) && !empty($person['image'])) : ?>
                    <img class="img-thumbnail" src="./uploads/<?php echo  $person['image']; ?>" width="100"/>
                    <a href="#"><i class="fa fa-times text-danger ms-3" id="remove-image-btn" data-id="<?php echo $person["id"]; ?>"></i></a>
                <?php  endif; ?>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Adresse</label>
                <textarea  class="form-control" id="address" name="address"><?php  echo $person['address'] ?? ''; ?></textarea>
            </div>
            <div class="mb-3">
                <label for="zip_code" class="form-label">Code postal</label>
                <input type="text" class="form-control" id="zip_code" name="zip_code" value="<?php  echo $person['zip_code'] ?? ''; ?>" >
            </div>
            <div class="mb-3">
                <label for="city" class="form-label">Ville</label>
                <input type="text" class="form-control" id="city" name="city" value="<?php  echo $person['city'] ?? ''; ?>" >
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Tél</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php  echo $person['phone'] ?? ''; ?>" >
            </div>
            <div class="mb-3">
                <label  class="form-label">Type de personne</label>
                <div class="form-check form-check-inline">
                    <input
                        class="form-check-input"
                        type="radio"
                        name="type"
                        id="type_1"
                        value="1"
                        <?php echo ((isset($person) && $person['type'] === 1) || !isset($person)) ? 'checked' : ''?>
                    >
                    <label class="form-check-label" for="type_1">Elève</label>
                </div>
                <div class="form-check form-check-inline">
                    <input
                        class="form-check-input"
                        type="radio"
                        name="type"
                        id="type_2"
                        value="2"
                        <?php echo (isset($person) && $person['type'] === 2) ? 'checked' : ''?>
                    >
                    <label class="form-check-label" for="type_2">Enseignant</label>
                </div>

            </div>
            <div class="mb-3">
                <label for="linked_user_id">Compte utilisateur lié</label>
                <select
                        name="linked_user_id"
                        id="linked_user_id"
                        class="form-control"
                        <?php  echo isset($person) && $person['user_id'] !== null ? 'disabled' :null; ?>
                        required
                >
                    <option value="">Veuille sélectionner un compte utilisateur</option>
                    <?php foreach ($unlinkedUsers as $unlinkedUser): ?>
                        <option
                                value="<?php echo  $unlinkedUser['id']; ?>"
                                <?php echo isset($person) &&  $person['user_id'] === $unlinkedUser['id'] ? 'selected' : null; ?>
                        >
                            <?php echo  $unlinkedUser['username']; ?>
                        </option>
                    <?php  endforeach; ?>
                </select>
            </div>

            <div class="mb-3 d-flex justify-content-end">
                <button type="button" class="btn btn-primary" data-id="<?php echo isset($person['id']) ?  $person['id'] : null; ?>" id="valid-form-person" name="<?php echo $action; ?>_button">Enregistrer</button>
            </div>
        </form>
    </div>
</div>
<script src="./assets/js/components/person.js" type="module"></script>
<script type="module">
    import {handlePersonForm,handleRemoveImageClick} from "./assets/js/components/person.js";

    document.addEventListener('DOMContentLoaded', () => {
        handlePersonForm()
        handleRemoveImageClick()
    })
</script>