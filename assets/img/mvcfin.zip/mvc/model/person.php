<?php
function getPerson(PDO $pdo, int $id): array | string
{
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query="SELECT p.*, up.user_id  FROM persons AS p 
    LEFT JOIN user_person AS up ON up.person_id = p.id 
    WHERE p.id = :id";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':id', $id, PDO::PARAM_INT);
    try
    {
        $prep->execute();
    }
    catch (PDOException $e)
    {
        return " erreur : ".$e->getCode() .' :</b> '. $e->getMessage();
    }

    $res = $prep->fetch();
    $prep->closeCursor();

    return $res;
}

function createPerson (
    PDO $pdo,
    string $lastName,
    string $firstName,
    string $address,
    string $zipCode,
    string $city,
    string $phone,
    int $type,
    string | null $image = null
)
{
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query="INSERT INTO persons (last_name, first_name, address, zip_code, city, phone, type, image) VALUES 
            (:last_name, :first_name, :address, :zip_code, :city, :phone, :type, :image)";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':last_name', $lastName,);
    $prep->bindValue(':first_name', $firstName,);
    $prep->bindValue(':address', $address);
    $prep->bindValue(':zip_code', $zipCode);
    $prep->bindValue(':city', $city);
    $prep->bindValue(':phone', $phone);
    $prep->bindValue(':image', $image);
    $prep->bindValue(':type', $type, PDO::PARAM_INT);
    try
    {
        $prep->execute();
        $id = (int)$pdo->lastInsertId();
    }
    catch (PDOException $e)
    {
        return " erreur : ".$e->getCode() .' :</b> '. $e->getMessage();
    }
    $prep->closeCursor();

    return $id;
}

function updatePerson (
    PDO $pdo,
    int $id,
    string $lastName,
    string $firstName,
    string $address,
    string $zipCode,
    string $city,
    string $phone,
    int $type
)
{
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query="UPDATE persons SET last_name = :last_name, first_name = :first_name, address = :address, 
                   zip_code = :zip_code, city = :city, phone = :phone, type = :type WHERE id = :id";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':last_name', $lastName,);
    $prep->bindValue(':first_name', $firstName,);
    $prep->bindValue(':address', $address);
    $prep->bindValue(':zip_code', $zipCode);
    $prep->bindValue(':city', $city);
    $prep->bindValue(':phone', $phone);
    $prep->bindValue(':type', $type, PDO::PARAM_INT);
    $prep->bindValue(':id', $id, PDO::PARAM_INT);
    try
    {
        $prep->execute();
    }
    catch (PDOException $e)
    {
        return " erreur : ".$e->getCode() .' :</b> '. $e->getMessage();
    }
    $prep->closeCursor();

    return true;
}

function linkUserToPerson(PDO $pdo, int $userId, int $personId)
{
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query="INSERT INTO user_person (user_id, person_id) VALUES (:user_id, :person_id)";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':user_id', $userId, PDO::PARAM_INT);
    $prep->bindValue(':person_id', $personId, PDO::PARAM_INT);
    try
    {
        $prep->execute();
    }
    catch (PDOException $e)
    {
        return " erreur : ".$e->getCode() .' :</b> '. $e->getMessage();
    }

    $prep->closeCursor();

    return true;
}

function resetImage(PDO $pdo, int $id)
{
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query="UPDATE persons SET image = NULL WHERE id = :id";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':id', $id, PDO::PARAM_INT);
    try
    {
        $prep->execute();
    }
    catch (PDOException $e)
    {
        return " erreur : ".$e->getCode() .' :</b> '. $e->getMessage();
    }
    $prep->closeCursor();

    return true;
}