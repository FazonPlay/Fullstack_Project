Before running this app think to update databse connexion in all models files's functions
example : 
![image](https://github.com/user-attachments/assets/e893873a-a555-4f61-8a54-3a4875b582e4)
A dump sql is available at the root of this project you need to import it
Ready !!!
You can connect to the app using the account titi / 2222

créer un dossier uploads à la racine du projet
