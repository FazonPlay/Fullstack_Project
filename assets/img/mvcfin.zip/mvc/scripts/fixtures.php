<?php
/**
* @var PDO $pdo
 */
require './includes/database.php';
require  './vendor/autoload.php';


$faker = Faker\Factory::create('fr_FR');

for ($i = 0; $i <= 100; $i++){
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query="INSERT INTO persons (last_name, first_name, address, zip_code, city, phone, type) VALUES 
            (:last_name, :first_name, :address, :zip_code, :city, :phone, :type)";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':last_name', $faker->lastName());
    $prep->bindValue(':first_name', $faker->firstName());
    $prep->bindValue(':address', $faker->address());
    $prep->bindValue(':zip_code', $faker->postcode());
    $prep->bindValue(':city', $faker->city());
    $prep->bindValue(':phone', $faker->phoneNumber());
    $prep->bindValue(':type', $faker->numberBetween(1,2), PDO::PARAM_INT);
    try
    {
        $prep->execute();
    }
    catch (PDOException $e)
    {
        echo " erreur : ".$e->getCode() .' :</b> '. $e->getMessage();
    }
    $prep->closeCursor();
}