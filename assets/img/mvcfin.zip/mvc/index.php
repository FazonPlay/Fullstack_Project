<?php
    session_start();
    require __DIR__ . '/vendor/autoload.php';
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
    require "includes/database.php";
    require "config/config.php";
    require ("includes/helper.php");


    if(isset($_GET['deconnect'])) {
        session_destroy();
        header("Location: index.php");
        exit();
    }

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest'
    ) {
        if(!empty($_SESSION['auth'])) {
            $componentName = !empty($_GET['component'])
                ? htmlspecialchars($_GET['component'], ENT_QUOTES, 'UTF-8')
                : 'users';

            $actionName = !empty($_GET['action'])
                ? htmlspecialchars($_GET['action'], ENT_QUOTES, 'UTF-8')
                : null;

            if (file_exists("controller/$componentName.php")) {
                require "controller/$componentName.php";
            } else {
                throw new Exception("Component '$componentName' does not exist");
            }
        } else {
            require "controller/login.php";
        }
        exit();
    }
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Expires" content="0" />
        <title>Mon App</title>
        <link href="includes/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="includes/fontawesome-free-6.7.1-web/css/all.min.css" />
    </head>
    <body>
        <div class="container-fluid pt-1">
            <?php
                if(!empty($_SESSION['auth'])) {
                require "_partials/_navbar.php";
                    $componentName = !empty($_GET['component'])
                    ? htmlspecialchars($_GET['component'], ENT_QUOTES, 'UTF-8')
                    : 'users';

                    if (file_exists("controller/$componentName.php")) {
                        require "controller/$componentName.php";
                    } else {
                        throw new Exception("Component '$componentName' does not exist");
                    }
                } else {
                    require "controller/login.php";
                }
            ?>
        </div>
        <?php require "_partials/_toast.html"; ?>
        <script src="includes/js/bootstrap.bundle.min.js"></script>
    </body>
</html>