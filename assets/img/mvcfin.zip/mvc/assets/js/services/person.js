export const getPersons = async (currentPage = 1) => {
    const response = await fetch(`index.php?component=persons&page=${currentPage}`, {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    return await response.json()
}

export const createPerson = async (form) =>  {

    const data = new FormData(form)

    const response = await fetch(`index.php?component=person&action=create`, {
        headers: {
          'X-Requested-With': 'XMLHttpRequest'
        },
        method: 'POST',
        body: data
    })

    return response.json()
}

export const updatePerson = async (form, id) =>  {

    const data = new FormData(form)

    const response = await fetch(`index.php?component=person&action=update&id=${id}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        },
        method: 'POST',
        body: data
    })

    return response.json()
}

export const resetImage = async (id) =>  {
    const response = await fetch(`index.php?component=person&action=delete_image&id=${id}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        },
        method: 'GET'
    })

    return response.json()
}