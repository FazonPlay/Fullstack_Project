<?php
const UPLOAD_DIRECTORY = '/mvc/uploads/';